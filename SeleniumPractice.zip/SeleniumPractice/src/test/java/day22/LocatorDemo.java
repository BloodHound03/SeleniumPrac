package day22;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;



public class LocatorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.amazon.in/");
		
		//name
		//WebElement searchBox=driver.findElement(By.name("field-keywords"));
		//searchBox.sendKeys("MacBook");
		
		//driver.findElement(By.name("field-keywords")).sendKeys("MacBook");
		
		//id
		//WebElement logo=driver.findElement(By.id("nav-logo-sprites"));
		//boolean status=logo.isDisplayed();
		//boolean status=driver.findElement(By.id("nav-logo-sprites")).isDisplayed();
		//System.out.println(status);
		
		//linktest and partialLinkedTest --- only for link
		//driver.findElement(By.linkText("Mobiles")).click(); //linkText
		//driver.findElement(By.partialLinkText("Prime Now")).click(); // partialLinkText
		
		//classname
		//List<WebElement> headerLinks = driver.findElements(By.className("nav-li"));
		//System.out.println(headerLinks.size());
		
		//tagName
		List<WebElement> headerLinks = driver.findElements(By.tagName("img"));
		System.out.println(headerLinks.size());		
	}

}
