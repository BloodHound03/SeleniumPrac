package day26;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetMethods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		//get(url) - opens url in the browser
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		//getTile() - returns title of the page
		System.out.println(driver.getTitle());
		
		//getCurrentUrl() - returns URL of the page
		System.out.println(driver.getCurrentUrl());
		
		//getPageSource()- returns page source of the code
		System.out.println(driver.getPageSource());
		
		//getWindowHandle()- returns ID of the single Browser window
		String ds=driver.getWindowHandle();
		System.out.println("Window Id: "+ds);
		
		//getWindowHandles() - returns ID's of multiple browser windows
		
		
		driver.close();
		
 	}

}
