package day26;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class ConditionalStatements {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new EdgeDriver();
		driver.get("https://www.amazon.in/");
		driver.manage().window().maximize();
		
		//isDisplayed()
		WebElement ds=driver.findElement(By.xpath("//*[@id=\"CardInstanceaG8XzoRs3BJJtje_CI-hJA\"]/a/img"));
		System.out.println("Display Status: "+ds.isDisplayed());
		
		driver.close();
	}

}
