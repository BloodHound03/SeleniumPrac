package day24;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class XPathDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.amazon.in/");
		driver.manage().window().maximize();
		
		//Xpath with  a single attribute
		//driver.findElement(By.xpath("//*[@id=\"twotabsearchtextbox\"]")).sendKeys("Iphone");
		
		//Xpath with  a multiple attribute
		//driver.findElement(By.xpath("//*[@id=\"twotabsearchtextbox\"][@placeholder=\"Search Amazon.in\"]")).sendKeys("Iphone");
		
		//xpath with 'and' and 'or'
		//driver.findElement(By.xpath("//*[@id=\"twotabsearchtextbox\" and @placeholder=\"Search Amazon.in\"]")).sendKeys("Iphone");
		//driver.findElement(By.xpath("//*[@id=\"twotabsearchtextbox\" or @placeholder=\"xyz\"]")).sendKeys("Iphone");
		
		//chained xpath
		driver.findElement(By.xpath("//*[@class=\"a-list-item\"]/a/img")).click();
	}

}
