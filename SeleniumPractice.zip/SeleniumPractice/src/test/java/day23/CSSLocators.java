package day23;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class CSSLocators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver=new ChromeDriver(); 
		driver.manage().window().maximize();
		driver.get("https://www.amazon.in/");
		
		//tag#id
		driver.findElement(By.cssSelector("input#twotabsearchtextbox")).sendKeys("oneplus");
		//driver.findElement(By.cssSelector("#twotabsearchtextbox")).sendKeys("oneplus");
		
		//tag.classname
		//driver.findElement(By.cssSelector("input.nav-input")).sendKeys("toys");
		//driver.findElement(By.id("nav-search-submit-button")).click();
		
		//tag attribute
		//driver.findElement(By.cssSelector("input[placeholder='Search Amazon.in']")).sendKeys("toys for kids");
		//driver.findElement(By.cssSelector("[placeholder='Search Amazon.in']")).sendKeys("toys for kids");
		//driver.findElement(By.cssSelector("[placeholder=\"Search Amazon.in\"]")).sendKeys("toys for kids");
		
		//tag class attribute
		//driver.findElement(By.cssSelector("input.nav-input[name=\"field-keywords\"]")).sendKeys("iphone");
		//driver.findElement(By.cssSelector(".nav-input[name=\"field-keywords\"]")).sendKeys("iphone");
	}

}
