package day21;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
//import org.openqa.selenium.chrome.ChromeDriver;


public class FirstTestCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * //1) Launch browser(chrome) //ChromeDriver driver = new ChromeDriver();
		 * WebDriver driver=new ChromeDriver();
		 * //driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10)); //2)
		 * open url driver.get("https://www.amazon.in/");
		 * 
		 * //3) validate String act_title=driver.getTitle(); if(act_title.
		 * equals("Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in"
		 * )) { System.out.println("Test Passed"); }else {
		 * System.out.println("Test Failed"); }
		 * 
		 * // 4) close browser //driver.quit() driver.close();
		 */
				
		//1) Launch browser(edge)
				//ChromeDriver driver = new ChromeDriver();
				WebDriver driver=new EdgeDriver();
				//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
				//2) open url
				driver.get("https://www.amazon.in/");
				
				//3) validate
				String act_title=driver.getTitle();
				if(act_title.equals("Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in")) {
					System.out.println("Test Passed");
				}else {
					System.out.println("Test Failed");
				}
				
				// 4) close browser
				//driver.quit()
				driver.close();



	}

}
